### THE SCRIPT BEGINS ###
library(stylo)
library(tictoc)

tic()

# xx1 - for words; xx2 - for characters

# Parameters: words, characters
# Parameters: classification methods: "delta", "svm", "nsc"
# - support vector machine
# - nearest shrunken centroids
# - delta
# Parameters: MFW

classifiers = c("svm", "delta", "nsc")
mfwVector   = c(100, 300, 500)
featType    = c("w", "c") 


for (iii in featType){
  if (iii == "w"){
    featType = "w"
    featLen  = "1"
    incr = 1
  } else {
    featType = "c"
    featLen  = "2"
    incr = 2
  }
  
  for (i in classifiers){
    for (ii in mfwVector){
      
      cat(paste("\n\n========Generating:", i, "for", ii, "features (", featType, featLen, ")========\n\n"))
      rolling.classify(write.pdf.file = TRUE, corpus.lang="Other",
                       analyzed.features = featType, ngram.size = featLen,
                       classification.method = i, mfw=ii+incr,
                       use.existing.freq.tables = TRUE,
                       training.set.sampling = "normal.sampling",
                       slice.size = 5000, slice.overlap = 4500)
      
    }
  }
}

toc()
